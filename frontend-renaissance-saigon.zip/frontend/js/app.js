let state = {
    rooms: [],
    customers: [],
    bookings: [],
    roomFilter: 'ALL',
    customerSearch: ''
};

const formatVND = (amount) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);

document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
    refreshAllData();
});

async function refreshAllData() {
    state.rooms = await window.apiService.getRooms();
    state.customers = await window.apiService.getCustomers();
    state.bookings = await window.apiService.getBookings();

    renderDashboard();
    renderRooms();
    renderCustomers();
    populateBookingSelects();
    renderReceptionDesk();
    updateApiStatusBadge();
}

function updateApiStatusBadge() {
    const badge = document.getElementById('apiModeBadge');
    if (API_CONFIG.USE_MOCK) {
        badge.textContent = 'MOCK API (LOCAL)';
        badge.className = 'px-3 py-1 text-xs font-semibold rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 cursor-pointer';
    } else {
        badge.textContent = 'LIVE API CONNECTED';
        badge.className = 'px-3 py-1 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 cursor-pointer';
    }
}

// Chuyển trang (Navigation) & đóng mở menu Mobile
function switchTab(tabId) {
    document.querySelectorAll('.tab-section').forEach(sec => sec.classList.add('hidden'));
    document.getElementById(`sec-${tabId}`).classList.remove('hidden');

    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
    if (activeBtn) activeBtn.classList.add('active');

    const titles = {
        dashboard: 'Tổng Quan Đại Sảnh (Executive Dashboard)',
        rooms: 'Quản Lý Hệ Thống Phòng Nghỉ',
        customers: 'Hồ Sơ Khách Hàng Thượng Lưu (VIP Guests)',
        booking: 'Khởi Tạo Đặt Phòng Mới (Reservation)',
        reception: 'Quầy Lễ Tân: Nhận Phòng & Trả Phòng'
    };
    document.getElementById('pageHeaderTitle').textContent = titles[tabId] || 'Renaissance Saigon';

    // Tự động thu gọn Sidebar trên màn hình điện thoại
    const sidebar = document.getElementById('mainSidebar');
    if (window.innerWidth < 1024) {
        sidebar.classList.add('-translate-x-full');
    }
}

// 2. RENDER DASHBOARD
function renderDashboard() {
    const total = state.rooms.length;
    const available = state.rooms.filter(r => r.status === 'AVAILABLE').length;
    const occupied = state.rooms.filter(r => r.status === 'OCCUPIED').length;
    const totalCustomers = state.customers.length;

    document.getElementById('statTotalRooms').textContent = total;
    document.getElementById('statAvailableRooms').textContent = available;
    document.getElementById('statOccupiedRooms').textContent = occupied;
    document.getElementById('statTotalCustomers').textContent = totalCustomers;

    const recentTbody = document.getElementById('dashboardRecentBookings');
    recentTbody.innerHTML = state.bookings.slice(0, 5).map(b => `
        <tr class="border-b border-stone-100 hover:bg-stone-50/80">
            <td class="py-3.5 px-4 font-semibold text-slate-900">${b.id}</td>
            <td class="py-3.5 px-4">${b.customerName}</td>
            <td class="py-3.5 px-4"><span class="font-semibold text-amber-800">Phòng ${b.roomNumber}</span> (${b.roomType})</td>
            <td class="py-3.5 px-4 text-sm text-slate-600">${b.checkIn} &rarr; ${b.checkOut}</td>
            <td class="py-3.5 px-4 font-semibold">${formatVND(b.totalPrice)}</td>
            <td class="py-3.5 px-4">${getBookingBadge(b.status)}</td>
        </tr>
    `).join('');
}

// 3. RENDER QUẢN LÝ PHÒNG
function getRoomBadge(status) {
    const map = {
        AVAILABLE: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">Phòng Trống</span>',
        OCCUPIED: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">Đang Thuê</span>',
        RESERVED: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">Đã Đặt Trước</span>',
        MAINTENANCE: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-200 text-slate-700">Bảo Trì</span>'
    };
    return map[status] || status;
}

function renderRooms() {
    const filtered = state.roomFilter === 'ALL'
        ? state.rooms
        : state.rooms.filter(r => r.status === state.roomFilter);

    const grid = document.getElementById('roomsGridContainer');
    grid.innerHTML = filtered.map(room => `
        <div class="luxury-card rounded-xl p-5 flex flex-col justify-between">
            <div>
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <span class="text-xs uppercase tracking-widest text-amber-700 font-semibold">Tầng ${room.floor}</span>
                        <h4 class="font-serif-luxury text-2xl font-bold text-slate-900">Phòng ${room.number}</h4>
                    </div>
                    ${getRoomBadge(room.status)}
                </div>
                <p class="text-sm font-medium text-slate-700 mb-1">${room.type}</p>
                <p class="text-lg font-bold text-amber-700 mb-4">${formatVND(room.price)} <span class="text-xs font-normal text-slate-500">/ đêm</span></p>
            </div>
            <div class="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
                <button onclick="openRoomModal('${room.id}')" class="px-3 py-1.5 text-xs font-medium rounded border border-amber-600/40 text-amber-800 hover:bg-amber-50">Chỉnh sửa</button>
                <button onclick="handleDeleteRoom('${room.id}')" class="px-3 py-1.5 text-xs font-medium rounded border border-rose-300 text-rose-700 hover:bg-rose-50">Xóa</button>
            </div>
        </div>
    `).join('');
}

window.openRoomModal = function(roomId = null) {
    const modal = document.getElementById('roomModal');
    const form = document.getElementById('roomForm');
    form.reset();
    document.getElementById('roomIdInput').value = '';

    if (roomId) {
        const room = state.rooms.find(r => r.id === roomId);
        if (room) {
            document.getElementById('roomModalTitle').textContent = `Cập Nhật Phòng ${room.number}`;
            document.getElementById('roomIdInput').value = room.id;
            document.getElementById('roomNumberInput').value = room.number;
            document.getElementById('roomFloorInput').value = room.floor;
            document.getElementById('roomTypeInput').value = room.type;
            document.getElementById('roomPriceInput').value = room.price;
            document.getElementById('roomStatusInput').value = room.status;
        }
    } else {
        document.getElementById('roomModalTitle').textContent = 'Thêm Phòng Nghỉ Hạng Sang Mới';
    }
    modal.classList.remove('hidden');
};

window.handleDeleteRoom = async function(id) {
    if (confirm('Xác nhận xóa phòng này khỏi danh mục quản lý?')) {
        await window.apiService.deleteRoom(id);
        await refreshAllData();
    }
};

// 4. RENDER QUẢN LÝ KHÁCH HÀNG
function renderCustomers() {
    const keyword = state.customerSearch.toLowerCase().trim();
    const list = state.customers.filter(c =>
        c.name.toLowerCase().includes(keyword) ||
        c.phone.includes(keyword) ||
        c.cccd.toLowerCase().includes(keyword)
    );

    const tbody = document.getElementById('customersTableBody');
    tbody.innerHTML = list.map(c => `
        <tr class="border-b border-stone-100 hover:bg-stone-50/80">
            <td class="py-3.5 px-4 font-semibold text-slate-900">${c.id}</td>
            <td class="py-3.5 px-4 font-medium">${c.name}</td>
            <td class="py-3.5 px-4">${c.phone}</td>
            <td class="py-3.5 px-4">${c.cccd}</td>
            <td class="py-3.5 px-4 text-sm text-slate-600">${c.email}</td>
            <td class="py-3.5 px-4"><span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100/80 text-amber-900 border border-amber-400/40">${c.tier}</span></td>
            <td class="py-3.5 px-4 text-right">
                <button onclick="openCustomerModal('${c.id}')" class="px-3 py-1 text-xs font-semibold rounded bg-slate-900 text-amber-300 hover:bg-slate-800">Sửa hồ sơ</button>
            </td>
        </tr>
    `).join('');
}

window.openCustomerModal = function(customerId = null) {
    const modal = document.getElementById('customerModal');
    const form = document.getElementById('customerForm');
    form.reset();
    document.getElementById('customerIdInput').value = '';

    if (customerId) {
        const c = state.customers.find(x => x.id === customerId);
        if (c) {
            document.getElementById('customerModalTitle').textContent = 'Chỉnh Sửa Thông Tin Khách Hàng';
            document.getElementById('customerIdInput').value = c.id;
            document.getElementById('customerNameInput').value = c.name;
            document.getElementById('customerPhoneInput').value = c.phone;
            document.getElementById('customerCccdInput').value = c.cccd;
            document.getElementById('customerEmailInput').value = c.email;
            document.getElementById('customerTierInput').value = c.tier;
        }
    } else {
        document.getElementById('customerModalTitle').textContent = 'Đăng Ký Hồ Sơ Khách Hàng Mới';
    }
    modal.classList.remove('hidden');
};

// 5. ĐẶT PHÒNG (BOOKING)
function populateBookingSelects() {
    const custSelect = document.getElementById('bookingCustomerSelect');
    custSelect.innerHTML = state.customers.map(c =>
        `<option value="${c.id}">${c.name} - ${c.phone} (${c.tier})</option>`
    ).join('');

    const availableRooms = state.rooms.filter(r => r.status === 'AVAILABLE');
    const roomSelect = document.getElementById('bookingRoomSelect');
    if (availableRooms.length === 0) {
        roomSelect.innerHTML = `<option value="">-- Hiện không còn phòng trống --</option>`;
    } else {
        roomSelect.innerHTML = availableRooms.map(r =>
            `<option value="${r.id}" data-price="${r.price}">Phòng ${r.number} - ${r.type} (${formatVND(r.price)}/đêm)</option>`
        ).join('');
    }
    calculateBookingPreview();
}

function calculateBookingPreview() {
    const roomSelect = document.getElementById('bookingRoomSelect');
    const selectedOpt = roomSelect.options[roomSelect.selectedIndex];
    const pricePerNight = selectedOpt && selectedOpt.dataset.price ? Number(selectedOpt.dataset.price) : 0;

    const checkInVal = document.getElementById('bookingCheckIn').value;
    const checkOutVal = document.getElementById('bookingCheckOut').value;

    let nights = 1;
    if (checkInVal && checkOutVal) {
        const diff = (new Date(checkOutVal) - new Date(checkInVal)) / (1000 * 60 * 60 * 24);
        nights = diff > 0 ? diff : 1;
    }

    const total = pricePerNight * nights;
    document.getElementById('bookingNightsPreview').textContent = `${nights} đêm`;
    document.getElementById('bookingTotalPreview').textContent = formatVND(total);
    return total;
}

// 6. NHẬN PHÒNG & TRẢ PHÒNG (RECEPTION)
function getBookingBadge(status) {
    const map = {
        RESERVED: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">Chờ Nhận Phòng</span>',
        CHECKED_IN: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">Đang Lưu Trú</span>',
        CHECKED_OUT: '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-200 text-slate-700">Đã Trả Phòng</span>'
    };
    return map[status] || status;
}

function renderReceptionDesk() {
    const tbody = document.getElementById('receptionTableBody');
    tbody.innerHTML = state.bookings.map(b => {
        let actionBtn = '<span class="text-xs text-slate-400 italic">Hoàn tất hồ sơ</span>';
        if (b.status === 'RESERVED') {
            actionBtn = `<button onclick="handleCheckIn('${b.id}')" class="px-3.5 py-1.5 rounded text-xs font-semibold gold-gradient-bg text-slate-950 shadow-sm hover:opacity-95">Nhận Phòng (Check-in)</button>`;
        } else if (b.status === 'CHECKED_IN') {
            actionBtn = `<button onclick="handleCheckOut('${b.id}')" class="px-3.5 py-1.5 rounded text-xs font-semibold bg-slate-900 text-amber-300 hover:bg-slate-800">Trả Phòng (Check-out)</button>`;
        }

        return `
            <tr class="border-b border-stone-100 hover:bg-stone-50/80">
                <td class="py-3.5 px-4 font-bold text-slate-900">${b.id}</td>
                <td class="py-3.5 px-4 font-medium">${b.customerName}</td>
                <td class="py-3.5 px-4"><span class="font-semibold text-amber-800">Phòng ${b.roomNumber}</span> - ${b.roomType}</td>
                <td class="py-3.5 px-4 text-sm">${b.checkIn}</td>
                <td class="py-3.5 px-4 text-sm">${b.checkOut}</td>
                <td class="py-3.5 px-4 font-semibold">${formatVND(b.totalPrice)}</td>
                <td class="py-3.5 px-4">${getBookingBadge(b.status)}</td>
                <td class="py-3.5 px-4 text-right">${actionBtn}</td>
            </tr>
        `;
    }).join('');
}

window.handleCheckIn = async function(bookingId) {
    await window.apiService.processCheckIn(bookingId);
    await refreshAllData();
};

window.handleCheckOut = async function(bookingId) {
    if (confirm('Xác nhận thanh toán hóa đơn và hoàn tất thủ tục Trả phòng (Check-out)?')) {
        await window.apiService.processCheckOut(bookingId);
        await refreshAllData();
    }
};

// KHỞI TẠO SỰ KIỆN
function initEventListeners() {
    // Ngày mặc định cho form Đặt phòng
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    document.getElementById('bookingCheckIn').value = today;
    document.getElementById('bookingCheckOut').value = tomorrow;

    // 1. Đăng nhập
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const user = document.getElementById('loginUsername').value;
        const pass = document.getElementById('loginPassword').value;
        await window.apiService.login(user, pass);
        document.getElementById('loginOverlay').classList.add('hidden');
    });

    document.getElementById('logoutBtn').addEventListener('click', () => {
        document.getElementById('loginOverlay').classList.remove('hidden');
    });

    // Chuyển đổi Mock/Live API nhanh cho nhóm test
    document.getElementById('apiModeBadge').addEventListener('click', () => {
        API_CONFIG.USE_MOCK = !API_CONFIG.USE_MOCK;
        updateApiStatusBadge();
    });

    // Menu điều hướng
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Nút mở Sidebar trên Mobile
    document.getElementById('mobileMenuBtn').addEventListener('click', () => {
        document.getElementById('mainSidebar').classList.toggle('-translate-x-full');
    });

    // Lọc phòng theo trạng thái
    document.querySelectorAll('.room-filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.room-filter-btn').forEach(b => {
                b.className = 'room-filter-btn px-4 py-2 rounded-lg text-xs font-semibold bg-white border border-stone-200 text-slate-700';
            });
            btn.className = 'room-filter-btn px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 text-amber-300';
            state.roomFilter = btn.dataset.status;
            renderRooms();
        });
    });

    // Lưu phòng (Thêm / Sửa)
    document.getElementById('roomForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            id: document.getElementById('roomIdInput').value || null,
            number: document.getElementById('roomNumberInput').value,
            floor: Number(document.getElementById('roomFloorInput').value),
            type: document.getElementById('roomTypeInput').value,
            price: Number(document.getElementById('roomPriceInput').value),
            status: document.getElementById('roomStatusInput').value
        };
        await window.apiService.saveRoom(payload);
        document.getElementById('roomModal').classList.add('hidden');
        await refreshAllData();
    });

    // Tìm kiếm & Lưu khách hàng
    document.getElementById('customerSearchInput').addEventListener('input', (e) => {
        state.customerSearch = e.target.value;
        renderCustomers();
    });

    document.getElementById('customerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            id: document.getElementById('customerIdInput').value || null,
            name: document.getElementById('customerNameInput').value,
            phone: document.getElementById('customerPhoneInput').value,
            cccd: document.getElementById('customerCccdInput').value,
            email: document.getElementById('customerEmailInput').value,
            tier: document.getElementById('customerTierInput').value
        };
        await window.apiService.saveCustomer(payload);
        document.getElementById('customerModal').classList.add('hidden');
        await refreshAllData();
    });

    // Tính toán tiền phòng tự động & Xác nhận đặt phòng
    ['bookingRoomSelect', 'bookingCheckIn', 'bookingCheckOut'].forEach(id => {
        document.getElementById(id).addEventListener('change', calculateBookingPreview);
    });

    document.getElementById('bookingForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const roomId = document.getElementById('bookingRoomSelect').value;
        if (!roomId) {
            alert('Vui lòng chọn phòng trống để đặt!');
            return;
        }
        const totalPrice = calculateBookingPreview();
        await window.apiService.createBooking({
            customerId: document.getElementById('bookingCustomerSelect').value,
            roomId,
            checkIn: document.getElementById('bookingCheckIn').value,
            checkOut: document.getElementById('bookingCheckOut').value,
            totalPrice
        });
        alert('Đã xác nhận đặt phòng thành công!');
        await refreshAllData();
        switchTab('reception');
    });
}
